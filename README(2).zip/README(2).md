# Ludo Kingdoms 🎮

A simple, fully playable Ludo game created for **VOSC Activity 1** using only HTML, CSS, and JavaScript.

## ✨ Features

- Four-player Ludo gameplay
- Four themed realms:
  - 🔥 Red — Fire Realm
  - 🌲 Green — Forest Realm
  - 🌊 Blue — Ocean Realm
  - ☀️ Yellow — Sun Realm
- Dice rolling
- A token can enter the board after rolling a 6
- Clickable/glowing tokens for legal moves
- Token capturing
- Safe spaces
- Turn management
- Extra turn after rolling a 6
- Win detection
- New Game / Play Again buttons
- Responsive design for smaller screens
- Fantasy kingdom-inspired visual theme

## 🛠️ Technologies Used

- **HTML5** — Structure of the game
- **CSS3** — Styling, layout, colors, animations, and responsive design
- **JavaScript** — Game logic, dice, turns, token movement, capturing, and winning

No frameworks or game engines are used.

## 📁 Project Structure

```text
VOSC Activity-1/
│
├── index.html
├── style.css
├── script.js
└── README.md
```

## ▶️ How to Run

### Method 1 — Browser

1. Download or clone the repository.
2. Keep all four files in the same folder.
3. Open `index.html` in a web browser.

### Method 2 — VS Code

1. Open the project folder in VS Code.
2. Open `index.html`.
3. Right-click the file.
4. Select **Open with Live Server**.

## 🎲 How to Play

1. The game starts with the **Red Realm**.
2. Click **ROLL DICE**.
3. A token can leave its home when you roll a **6**.
4. Click a highlighted/glowing token to move it.
5. If your token lands on an opponent's token, that token is captured and sent back home.
6. Safe spaces cannot be used for capturing.
7. Rolling a **6** gives the same player another turn.
8. Move all four of your tokens to the Royal Castle to win.

## 🎨 Design

The interface uses a fantasy-kingdom-inspired theme with warm earthy colors, castle elements, blocky/pixel-inspired tokens, and a muted sunset palette.

## 👩‍💻 VOSC Activity 1

**Activity:** Build a Simple Game  
**Game:** Ludo  
**Technologies:** HTML, CSS, JavaScript
